package com.mli.posv.fetchproduct.questions.request;

import java.util.List;

import com.mli.posv.fetchproduct.questions.entity.PiMproSellerTransaction;
import com.mli.posv.fetchproduct.questions.entity.PiMproQuestionMst;

public class Response {

	private String status;
	private String description;
	private String txnId;
	private String expiryLink;
	private PiMproSellerTransaction sellerInformation;
	private List<PiMproQuestionMst> questions;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	public PiMproSellerTransaction getSellerInformation() {
		return sellerInformation;
	}
	public void setSellerInformation(PiMproSellerTransaction sellerInformation) {
		this.sellerInformation = sellerInformation;
	}
	public List<PiMproQuestionMst> getQuestions() {
		return questions;
	}
	public void setQuestions(List<PiMproQuestionMst> questions) {
		this.questions = questions;
	}
	public String getExpiryLink() {
		return expiryLink;
	}
	public void setExpiryLink(String expiryLink) {
		this.expiryLink = expiryLink;
	}
	@Override
	public String toString() {
		return "Response [status=" + status + ", description=" + description + ", txnId=" + txnId + ", expiryLink="
				+ expiryLink + ", sellerInformation=" + sellerInformation + ", questions=" + questions + "]";
	}
}
