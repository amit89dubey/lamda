package com.mli.posv.fetchproduct.questions.request;

public class Request {

	private String txnId;

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	@Override
	public String toString() {
		return "Request [txnId=" + txnId + "]";
	}
}
