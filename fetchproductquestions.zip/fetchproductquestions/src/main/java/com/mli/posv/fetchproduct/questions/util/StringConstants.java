package com.mli.posv.fetchproduct.questions.util;

public class StringConstants {
	public static final String SUCCESS = "SUCCESS";
	public static final String SUCCESS_MSG = "Request Successfully Processed";
	public static final String FAILURE = "FAILURE";
	public static final String INVALIDREQUEST = "Kindly check your Request details and try again";
	public static final String EXCEPTION = "Something went wrong please connect with customer support";
	public static final String DB_EXCEPTION = "We found exception while DB activity";
	public static final String BLANK_DB = "No data found from database for requested details";
	public static final String BLANK_SELLER = "Seller information not found aggenst shared transaction please try after sometime";
	public static final String BLANK_QUESTIONS = "Questions information not found aggenst shared transaction please try after sometime";
	public static final String COLON = " : ";
	public static final String SEPERATOR = "||";
	public static final String STATUS_ZERO = "0";
	public static final String STATUS_ONE = "1";
	
	//DB details
	public static final String PI_MPRO_SELLER_TRANSACTION = "PI_MPRO_SELLER_TRANSACTION";
	public static final String PI_MPRO_QUESTION_MST = "PI_MPRO_QUESTION_MST";
	public static final String PI_MPRO_BUYER_TRANSACTION = "PI_MPRO_BUYER_TRANSACTION";

}
