package com.mli.posv.fetchproduct.questions.entity;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
@DynamoDBTable(tableName = "PI_MPRO_QUESTION_MST" )
public class PiMproQuestionMst {

	@DynamoDBAttribute(attributeName="Q_GROUP_ID")
	@JsonProperty(value="Q_GROUP_ID")
	private String groupId;
	
	@DynamoDBAttribute(attributeName="QUESTION_NAME")
	@JsonProperty(value="QUESTION_NAME")
	private String questionName;
	
	@DynamoDBHashKey(attributeName="QUESTION_SEQ")
	@JsonProperty(value="QUESTION_SEQ")
	private String questionSeq;
	
	@DynamoDBAttribute(attributeName="DYNAMIC_NAME")
	@JsonProperty(value="DYNAMIC_NAME")
	private String dynamicName;
	
	@DynamoDBAttribute(attributeName="SELLER_QUESTION_MAPPING")
	@JsonProperty(value="SELLER_QUESTION_MAPPING")
	private String sellerQuestionMapping;
	
	@DynamoDBAttribute(attributeName="Q_COMMENT")
	@JsonProperty(value="Q_COMMENT")
	private String comment;
	
//	@DynamoDBAttribute(attributeName="Q_CODE")
	private String count;
	
	//@DynamoDBAttribute(attributeName="AGNTVINTGDATE")
	private int percent;
	
	@DynamoDBAttribute(attributeName="Q_CODE")
	@JsonProperty(value="Q_CODE")
	private String questionid;
	
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getQuestionName() {
		return questionName;
	}
	public void setQuestionName(String questionName) {
		this.questionName = questionName;
	}
	public String getQuestionSeq() {
		return questionSeq;
	}
	public void setQuestionSeq(String questionSeq) {
		this.questionSeq = questionSeq;
	}
	public String getDynamicName() {
		return dynamicName;
	}
	public void setDynamicName(String dynamicName) {
		this.dynamicName = dynamicName;
	}
	public String getSellerQuestionMapping() {
		return sellerQuestionMapping;
	}
	public void setSellerQuestionMapping(String sellerQuestionMapping) {
		this.sellerQuestionMapping = sellerQuestionMapping;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public int getPercent() {
		return percent;
	}
	public void setPercent(int percent) {
		this.percent = percent;
	}
	public String getQuestionid() {
		return questionid;
	}
	public void setQuestionid(String questionid) {
		this.questionid = questionid;
	}	
}
