package com.mli.posv.fetchproduct.questions.dao;

import java.util.List;

import com.amazonaws.services.lambda.runtime.Context;
import com.mli.posv.fetchproduct.questions.entity.PiMproSellerTransaction;
import com.mli.posv.fetchproduct.questions.entity.PiMproQuestionMst;

public interface ProductDao {
	PiMproSellerTransaction getPiSellerDetails(String txnIde, Context context);
	List<PiMproQuestionMst> getMproSlideQuestionsByCustGroupId(PiMproSellerTransaction resultSet, Context context);
	public String getExpiryLnikStatus(String expiryStatus, Context context);
	String updateAppSource(String txnIde, String appSource);
}
