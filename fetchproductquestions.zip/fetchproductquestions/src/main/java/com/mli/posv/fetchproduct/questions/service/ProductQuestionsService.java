package com.mli.posv.fetchproduct.questions.service;

import com.amazonaws.services.lambda.runtime.Context;
import com.mli.posv.fetchproduct.questions.request.Request;
import com.mli.posv.fetchproduct.questions.request.Response;

public interface ProductQuestionsService {

	public Response getProductQuestions(Request request, Context context); 
}
