package com.mli.posv.fetchproduct.questions.entity;

import java.io.Serializable;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
@DynamoDBTable(tableName = "PI_MPRO_SELLER_TRANSACTION" )
public class PiMproSellerTransaction implements Serializable {

	private static final long serialVersionUID = 1L;

	@DynamoDBHashKey(attributeName = "TXNID")
	@JsonProperty(value="TXNID")
	private String posvRefNumber;
	
	@JsonProperty(value="AGNTVINTGDATE")
	@DynamoDBAttribute(attributeName="AGNTVINTGDATE")
	private String agntVintgDate;
	
	@JsonProperty(value="AGNTPERSISTENCY")
	@DynamoDBAttribute(attributeName="AGNTPERSISTENCY")
	private String agntPersistency;
	
	@JsonProperty(value="PSMLOGIC")
	@DynamoDBAttribute(attributeName="PSMLOGIC")
	private String psmLogic;
	
	@JsonProperty(value="REPLSMNTSALE")
	@DynamoDBAttribute(attributeName="REPLSMNTSALE")
	private String replsmntSale;
	
	@JsonProperty(value="ECSDETAILS")
	@DynamoDBAttribute(attributeName="ECSDETAILS")
	private String ecsDetails;
	
	@JsonProperty(value="AGENTMOBILENUMBER")
	@DynamoDBAttribute(attributeName="AGENTMOBILENUMBER")
	private String agntMobileNumber;
	
	@JsonProperty(value="CUSTFNAME")
	@DynamoDBAttribute(attributeName="CUSTFNAME")
	private String proposerFirstname;
	
	@JsonProperty(value="CUSTLNAME")
	@DynamoDBAttribute(attributeName="CUSTLNAME")
	private String proposerLastName;
	
	@JsonProperty(value="CUSTMNAME")
	@DynamoDBAttribute(attributeName="CUSTMNAME")
	private String proposermidName;
	
	@JsonProperty(value="CUSTAGE")
	@DynamoDBAttribute(attributeName="CUSTAGE")
	private String proposerAge;
	
	@JsonProperty(value="PROPOSERMOBNUM")
	@DynamoDBAttribute(attributeName="PROPOSERMOBNUM")
	private String proposermobNum;
	
	@JsonProperty(value="CUSTEMAILID")
	@DynamoDBAttribute(attributeName="CUSTEMAILID")
	private String proposerEmail;
	
	@JsonProperty(value="INSRAGE")
	@DynamoDBAttribute(attributeName="INSRAGE")
	private String insurAge;
	
	@JsonProperty(value="INSRFNAME")
	@DynamoDBAttribute(attributeName="INSRFNAME")
	private String insurFirstName;
	
	@JsonProperty(value="INSRMNAME")
	@DynamoDBAttribute(attributeName="INSRMNAME")
	private String insurMidName;
	
	@JsonProperty(value="INSRLNAME")
	@DynamoDBAttribute(attributeName="INSRLNAME")
	private String insurLastName;
	
	@JsonProperty(value="INSRMOBILENO")
	@DynamoDBAttribute(attributeName="INSRMOBILENO")
	private String insurMobileNumber;
	
	@JsonProperty(value="INSREMAILID")
	@DynamoDBAttribute(attributeName="INSREMAILID")
	private String insurEmail;
	
	@JsonProperty(value="CUSTPERSISTENCYTYPE")
	@DynamoDBAttribute(attributeName="CUSTPERSISTENCYTYPE")
	private String typeOfProduct;
	
	@JsonProperty(value="CUSTBENEFITNAME")
	@DynamoDBAttribute(attributeName="CUSTBENEFITNAME")
	private String productName;
	
	@JsonProperty(value="INSURGROUPID")
	@DynamoDBAttribute(attributeName="INSURGROUPID")
	private String insurGroupId;
	
	@JsonProperty(value="CUSTTERMPERIOD")
	@DynamoDBAttribute(attributeName="CUSTTERMPERIOD")
	private String premiumPayTerm;
	
	@JsonProperty(value="CUSTPREMIUMTHRO")
	@DynamoDBAttribute(attributeName="CUSTPREMIUMTHRO")
	private String futurePremiumThro;
	
	@JsonProperty(value="CUSTSUMASRDAPLID")
	@DynamoDBAttribute(attributeName="CUSTSUMASRDAPLID")
	private String sumAssured;
	
	@JsonProperty(value="CUSTINIPREMPAY")
	@DynamoDBAttribute(attributeName="CUSTINIPREMPAY")
	private String initialPremiumPaid;
	
	@JsonProperty(value="CUSTMATURITYPERIOD")
	@DynamoDBAttribute(attributeName="CUSTMATURITYPERIOD")
	private String policyTerm;
	
	@JsonProperty(value="DT_CREATED")
	@DynamoDBAttribute(attributeName="DT_CREATED")
	private String dateCreated;
	
	@JsonProperty(value="AGNTID")
	@DynamoDBAttribute(attributeName="AGNTID")
	private String agntId;
	
	@JsonProperty(value="AGTGOCODE")
	@DynamoDBAttribute(attributeName="AGTGOCODE")
	private String agntGoCode;
	
	@JsonProperty(value="AGTCHANELNAME")
	@DynamoDBAttribute(attributeName="AGTCHANELNAME")
	private String agntChanelName;
	
	@JsonProperty(value="SMSTRIGERED")
	@DynamoDBAttribute(attributeName="SMSTRIGERED")
	private String smsTrigered;
	
	@JsonProperty(value="SMSDATE")
	@DynamoDBAttribute(attributeName="SMSDATE")
	private String smsDate;
	
	@JsonProperty(value="FEEDBACK")
	@DynamoDBAttribute(attributeName="FEEDBACK")
	private String feedBack;
	
	@JsonProperty(value="FEEDBACKSMSTRIGRD")
	@DynamoDBAttribute(attributeName="FEEDBACKSMSTRIGRD")
	private String feedBackSmsTrigrd;
	
	@JsonProperty(value="DT_FDBKSMSTRIGGERED")
	@DynamoDBAttribute(attributeName="DT_FDBKSMSTRIGGERED")
	private String dateFeedBackSmsTrigrd;
	
	@JsonProperty(value="AGENTNAME")
	@DynamoDBAttribute(attributeName="AGENTNAME")
	private String agntname;
	
	@JsonProperty(value="VERIFICATION_SOURCE")
	@DynamoDBAttribute(attributeName="VERIFICATION_SOURCE")
	private String verificationSource;
	
	@JsonProperty(value="ISWOPTRUE")
	@DynamoDBAttribute(attributeName="ISWOPTRUE")
	private String isWopTrue;
	
	@JsonProperty(value="MPRO_POLICYNUMBER")
	@DynamoDBAttribute(attributeName="MPRO_POLICYNUMBER")
	private String policyNumber;
	
	@JsonProperty(value="SOURCE")
	@DynamoDBAttribute(attributeName="SOURCE")
	private String source;

	// WAZ-3086
	@JsonProperty(value="REFERENCEKEY")
	@DynamoDBAttribute(attributeName="REFERENCEKEY")
	private String referenceKey;
	
	@JsonProperty(value="SMOKERTAG")
	@DynamoDBAttribute(attributeName="SMOKERTAG")
	private String smokerTag;
	
	@JsonProperty(value="VESTINGAGE")
	@DynamoDBAttribute(attributeName="VESTINGAGE")
	private String vestingAge;
	
	@JsonProperty(value="FYPPRETURNPER")
	@DynamoDBAttribute(attributeName="FYPPRETURNPER")
	private String fyppReturnPer;
	
	@JsonProperty(value="FUNDTYPE")
	@DynamoDBAttribute(attributeName="FUNDTYPE")
	private String fundType;

	// WAZ-3130
	@JsonProperty(value="PLANCODE")
	@DynamoDBAttribute(attributeName="PLANCODE")
	private String plancode;
	
	//WAZ-3430
	@JsonProperty(value="PREMIUMBACKOPTION")
	@DynamoDBAttribute(attributeName="PREMIUMBACKOPTION")
	private String premiumBackOption;
	
	@JsonProperty(value="GUARANTEEDSUMASSURED")
	@DynamoDBAttribute(attributeName="GUARANTEEDSUMASSURED")
    private String guaranteedSumAssured;
	
	@JsonProperty(value="MATURITYBENEFIT4PERS")
	@DynamoDBAttribute(attributeName="MATURITYBENEFIT4PERS")
    private String maturityBenefit4pers;
    
	@JsonProperty(value="MATURITYBENEFIT8PERS")
    @DynamoDBAttribute(attributeName="MATURITYBENEFIT8PERS")
    private String maturityBenefit8pers;
    
    //
	@JsonProperty(value="QUFNAME")
    @DynamoDBAttribute(attributeName="QUFNAME")
    private String qufName;
   
	@JsonProperty(value="QUMNAME")
    @DynamoDBAttribute(attributeName="QUMNAME")
    private String qumName;
    
	@JsonProperty(value="QULNAME")
    @DynamoDBAttribute(attributeName="QULNAME")
    private String qulName;
    
	@JsonProperty(value="QUAGE")
    @DynamoDBAttribute(attributeName="QUAGE")
    private String quAge;
    
	@JsonProperty(value="QUMOBILENO")
    @DynamoDBAttribute(attributeName="QUMOBILENO")
    private String quMobileNo;
    
	@JsonProperty(value="QUEMAILID")
    @DynamoDBAttribute(attributeName="QUEMAILID")
    private String quEmailId;
    
	@JsonProperty(value="QUINSRAGE")
    @DynamoDBAttribute(attributeName="QUINSRAGE")
    private String quInsrAge;
    
	@JsonProperty(value="QUINSRFNAME")
    @DynamoDBAttribute(attributeName="QUINSRFNAME")
    private String quInsrfName;
    
	@JsonProperty(value="QUINSRMNAME")
    @DynamoDBAttribute(attributeName="QUINSRMNAME")
    private String quInsrmName;
    
	@JsonProperty(value="QUINSRLNAME")
    @DynamoDBAttribute(attributeName="QUINSRLNAME")
    private String quInsrlName;
    
	@JsonProperty(value="QUINSRMOBILENO")
    @DynamoDBAttribute(attributeName="QUINSRMOBILENO")
    private String quInsrMobileNo;
    
	@JsonProperty(value="QUINSREMAILID")
    @DynamoDBAttribute(attributeName="QUINSREMAILID")
    private String quInsrEmailId;
    
	@JsonProperty(value="QUPERSISTENCYTYPE")
    @DynamoDBAttribute(attributeName="QUPERSISTENCYTYPE")
    private String quPersistencyType;
    
	@JsonProperty(value="QUBENEFITNAME")
    @DynamoDBAttribute(attributeName="QUBENEFITNAME")
    private String quBenefitName;
    
	@JsonProperty(value="CUSTGROUPID")
    @DynamoDBAttribute(attributeName="CUSTGROUPID")
    private String custGroupId;
    
	@JsonProperty(value="QUTERMPERIOD")
    @DynamoDBAttribute(attributeName="QUTERMPERIOD")
    private String quTermPeriod;
    
	@JsonProperty(value="QUPREMIUMTHRO")
    @DynamoDBAttribute(attributeName="QUPREMIUMTHRO")
    private String quPremiumThro;
    
	@JsonProperty(value="QUSUMASRDAPLID")
    @DynamoDBAttribute(attributeName="QUSUMASRDAPLID")
    private String quSumAsrdaplId;
    
	@JsonProperty(value="QUINIPREMPAY")
    @DynamoDBAttribute(attributeName="QUINIPREMPAY")
    private String quiniPremPay;
    
	@JsonProperty(value="QUMATURITYPERIOD")
    @DynamoDBAttribute(attributeName="QUMATURITYPERIOD")
    private String quMaturityPeriod;
    
	@JsonProperty(value="AGENTTENURE")
    @DynamoDBAttribute(attributeName="AGENTTENURE")
    private String agentTenure;
    
	@JsonProperty(value="MPROBITLYLINK")
    @DynamoDBAttribute(attributeName="MPROBITLYLINK")
    private String   mproBitlyLink;

    
	@JsonProperty(value="EMAILDATE")
    @DynamoDBAttribute(attributeName="EMAILDATE")
	private String emailDate;

	@JsonProperty(value="MPROPRODUCTLINK")
    @DynamoDBAttribute(attributeName="MPROPRODUCTLINK")
    private String   mproProductLink;
    
	@JsonProperty(value="MODEOFPAYMENT")
    @DynamoDBAttribute(attributeName="MODEOFPAYMENT")
    private String modeOfPayment;
    
	@JsonProperty(value="ILLUSTRATIONLINK")
	@DynamoDBAttribute(attributeName="ILLUSTRATIONLINK")
	private String illustrationLink;
	
	@JsonProperty(value="LINKEXPIRED")
	@DynamoDBAttribute(attributeName="LINKEXPIRED")
	private String linkExpired;

	
	public String getLinkExpired() {
		return linkExpired;
	}

	public void setLinkExpired(String linkExpired) {
		this.linkExpired = linkExpired;
	}

	public String getPosvRefNumber() {
		return posvRefNumber;
	}

	public void setPosvRefNumber(String posvRefNumber) {
		this.posvRefNumber = posvRefNumber;
	}

	public String getAgntVintgDate() {
		return agntVintgDate;
	}

	public void setAgntVintgDate(String agntVintgDate) {
		this.agntVintgDate = agntVintgDate;
	}

	public String getAgntPersistency() {
		return agntPersistency;
	}

	public void setAgntPersistency(String agntPersistency) {
		this.agntPersistency = agntPersistency;
	}

	public String getPsmLogic() {
		return psmLogic;
	}

	public void setPsmLogic(String psmLogic) {
		this.psmLogic = psmLogic;
	}

	public String getReplsmntSale() {
		return replsmntSale;
	}

	public void setReplsmntSale(String replsmntSale) {
		this.replsmntSale = replsmntSale;
	}

	public String getEcsDetails() {
		return ecsDetails;
	}

	public void setEcsDetails(String ecsDetails) {
		this.ecsDetails = ecsDetails;
	}

	public String getAgntMobileNumber() {
		return agntMobileNumber;
	}

	public void setAgntMobileNumber(String agntMobileNumber) {
		this.agntMobileNumber = agntMobileNumber;
	}

	public String getProposerFirstname() {
		return proposerFirstname;
	}

	public void setProposerFirstname(String proposerFirstname) {
		this.proposerFirstname = proposerFirstname;
	}

	public String getProposerLastName() {
		return proposerLastName;
	}

	public void setProposerLastName(String proposerLastName) {
		this.proposerLastName = proposerLastName;
	}

	public String getProposermidName() {
		return proposermidName;
	}

	public void setProposermidName(String proposermidName) {
		this.proposermidName = proposermidName;
	}

	public String getProposerAge() {
		return proposerAge;
	}

	public void setProposerAge(String proposerAge) {
		this.proposerAge = proposerAge;
	}

	public String getProposermobNum() {
		return proposermobNum;
	}

	public void setProposermobNum(String proposermobNum) {
		this.proposermobNum = proposermobNum;
	}

	public String getProposerEmail() {
		return proposerEmail;
	}

	public void setProposerEmail(String proposerEmail) {
		this.proposerEmail = proposerEmail;
	}

	public String getInsurAge() {
		return insurAge;
	}

	public void setInsurAge(String insurAge) {
		this.insurAge = insurAge;
	}

	public String getInsurFirstName() {
		return insurFirstName;
	}

	public void setInsurFirstName(String insurFirstName) {
		this.insurFirstName = insurFirstName;
	}

	public String getInsurMidName() {
		return insurMidName;
	}

	public void setInsurMidName(String insurMidName) {
		this.insurMidName = insurMidName;
	}

	public String getInsurLastName() {
		return insurLastName;
	}

	public void setInsurLastName(String insurLastName) {
		this.insurLastName = insurLastName;
	}

	public String getInsurMobileNumber() {
		return insurMobileNumber;
	}

	public void setInsurMobileNumber(String insurMobileNumber) {
		this.insurMobileNumber = insurMobileNumber;
	}

	public String getInsurEmail() {
		return insurEmail;
	}

	public void setInsurEmail(String insurEmail) {
		this.insurEmail = insurEmail;
	}

	public String getTypeOfProduct() {
		return typeOfProduct;
	}

	public void setTypeOfProduct(String typeOfProduct) {
		this.typeOfProduct = typeOfProduct;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getInsurGroupId() {
		return insurGroupId;
	}

	public void setInsurGroupId(String insurGroupId) {
		this.insurGroupId = insurGroupId;
	}

	public String getPremiumPayTerm() {
		return premiumPayTerm;
	}

	public void setPremiumPayTerm(String premiumPayTerm) {
		this.premiumPayTerm = premiumPayTerm;
	}

	public String getFuturePremiumThro() {
		return futurePremiumThro;
	}

	public void setFuturePremiumThro(String futurePremiumThro) {
		this.futurePremiumThro = futurePremiumThro;
	}

	public String getSumAssured() {
		return sumAssured;
	}

	public void setSumAssured(String sumAssured) {
		this.sumAssured = sumAssured;
	}

	public String getInitialPremiumPaid() {
		return initialPremiumPaid;
	}

	public void setInitialPremiumPaid(String initialPremiumPaid) {
		this.initialPremiumPaid = initialPremiumPaid;
	}

	public String getPolicyTerm() {
		return policyTerm;
	}

	public void setPolicyTerm(String policyTerm) {
		this.policyTerm = policyTerm;
	}

	public String getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(String dateCreated) {
		this.dateCreated = dateCreated;
	}

	public String getAgntId() {
		return agntId;
	}

	public void setAgntId(String agntId) {
		this.agntId = agntId;
	}

	public String getAgntGoCode() {
		return agntGoCode;
	}

	public void setAgntGoCode(String agntGoCode) {
		this.agntGoCode = agntGoCode;
	}

	public String getAgntChanelName() {
		return agntChanelName;
	}

	public void setAgntChanelName(String agntChanelName) {
		this.agntChanelName = agntChanelName;
	}

	public String getSmsTrigered() {
		return smsTrigered;
	}

	public void setSmsTrigered(String smsTrigered) {
		this.smsTrigered = smsTrigered;
	}

	public String getSmsDate() {
		return smsDate;
	}

	public void setSmsDate(String smsDate) {
		this.smsDate = smsDate;
	}

	public String getFeedBack() {
		return feedBack;
	}

	public void setFeedBack(String feedBack) {
		this.feedBack = feedBack;
	}

	public String getFeedBackSmsTrigrd() {
		return feedBackSmsTrigrd;
	}

	public void setFeedBackSmsTrigrd(String feedBackSmsTrigrd) {
		this.feedBackSmsTrigrd = feedBackSmsTrigrd;
	}

	public String getDateFeedBackSmsTrigrd() {
		return dateFeedBackSmsTrigrd;
	}

	public void setDateFeedBackSmsTrigrd(String dateFeedBackSmsTrigrd) {
		this.dateFeedBackSmsTrigrd = dateFeedBackSmsTrigrd;
	}

	public String getAgntname() {
		return agntname;
	}

	public void setAgntname(String agntname) {
		this.agntname = agntname;
	}

	public String getVerificationSource() {
		return verificationSource;
	}

	public void setVerificationSource(String verificationSource) {
		this.verificationSource = verificationSource;
	}

	public String getIsWopTrue() {
		return isWopTrue;
	}

	public void setIsWopTrue(String isWopTrue) {
		this.isWopTrue = isWopTrue;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(String policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getReferenceKey() {
		return referenceKey;
	}

	public void setReferenceKey(String referenceKey) {
		this.referenceKey = referenceKey;
	}

	public String getSmokerTag() {
		return smokerTag;
	}

	public void setSmokerTag(String smokerTag) {
		this.smokerTag = smokerTag;
	}

	public String getVestingAge() {
		return vestingAge;
	}

	public void setVestingAge(String vestingAge) {
		this.vestingAge = vestingAge;
	}

	public String getFyppReturnPer() {
		return fyppReturnPer;
	}

	public void setFyppReturnPer(String fyppReturnPer) {
		this.fyppReturnPer = fyppReturnPer;
	}

	public String getFundType() {
		return fundType;
	}

	public void setFundType(String fundType) {
		this.fundType = fundType;
	}

	public String getPlancode() {
		return plancode;
	}

	public void setPlancode(String plancode) {
		this.plancode = plancode;
	}

	public String getPremiumBackOption() {
		return premiumBackOption;
	}

	public void setPremiumBackOption(String premiumBackOption) {
		this.premiumBackOption = premiumBackOption;
	}

	public String getGuaranteedSumAssured() {
		return guaranteedSumAssured;
	}

	public void setGuaranteedSumAssured(String guaranteedSumAssured) {
		this.guaranteedSumAssured = guaranteedSumAssured;
	}

	public String getMaturityBenefit4pers() {
		return maturityBenefit4pers;
	}

	public void setMaturityBenefit4pers(String maturityBenefit4pers) {
		this.maturityBenefit4pers = maturityBenefit4pers;
	}

	public String getMaturityBenefit8pers() {
		return maturityBenefit8pers;
	}

	public void setMaturityBenefit8pers(String maturityBenefit8pers) {
		this.maturityBenefit8pers = maturityBenefit8pers;
	}

	public String getQufName() {
		return qufName;
	}

	public void setQufName(String qufName) {
		this.qufName = qufName;
	}

	public String getQumName() {
		return qumName;
	}

	public void setQumName(String qumName) {
		this.qumName = qumName;
	}

	public String getQulName() {
		return qulName;
	}

	public void setQulName(String qulName) {
		this.qulName = qulName;
	}

	public String getQuAge() {
		return quAge;
	}

	public void setQuAge(String quAge) {
		this.quAge = quAge;
	}

	public String getQuMobileNo() {
		return quMobileNo;
	}

	public void setQuMobileNo(String quMobileNo) {
		this.quMobileNo = quMobileNo;
	}

	public String getQuEmailId() {
		return quEmailId;
	}

	public void setQuEmailId(String quEmailId) {
		this.quEmailId = quEmailId;
	}

	public String getQuInsrAge() {
		return quInsrAge;
	}

	public void setQuInsrAge(String quInsrAge) {
		this.quInsrAge = quInsrAge;
	}

	public String getQuInsrfName() {
		return quInsrfName;
	}

	public void setQuInsrfName(String quInsrfName) {
		this.quInsrfName = quInsrfName;
	}

	public String getQuInsrmName() {
		return quInsrmName;
	}

	public void setQuInsrmName(String quInsrmName) {
		this.quInsrmName = quInsrmName;
	}

	public String getQuInsrlName() {
		return quInsrlName;
	}

	public void setQuInsrlName(String quInsrlName) {
		this.quInsrlName = quInsrlName;
	}

	public String getQuInsrMobileNo() {
		return quInsrMobileNo;
	}

	public void setQuInsrMobileNo(String quInsrMobileNo) {
		this.quInsrMobileNo = quInsrMobileNo;
	}

	public String getQuInsrEmailId() {
		return quInsrEmailId;
	}

	public void setQuInsrEmailId(String quInsrEmailId) {
		this.quInsrEmailId = quInsrEmailId;
	}

	public String getQuPersistencyType() {
		return quPersistencyType;
	}

	public void setQuPersistencyType(String quPersistencyType) {
		this.quPersistencyType = quPersistencyType;
	}

	public String getQuBenefitName() {
		return quBenefitName;
	}

	public void setQuBenefitName(String quBenefitName) {
		this.quBenefitName = quBenefitName;
	}

	public String getCustGroupId() {
		return custGroupId;
	}

	public void setCustGroupId(String custGroupId) {
		this.custGroupId = custGroupId;
	}

	public String getQuTermPeriod() {
		return quTermPeriod;
	}

	public void setQuTermPeriod(String quTermPeriod) {
		this.quTermPeriod = quTermPeriod;
	}

	public String getQuPremiumThro() {
		return quPremiumThro;
	}

	public void setQuPremiumThro(String quPremiumThro) {
		this.quPremiumThro = quPremiumThro;
	}

	public String getQuSumAsrdaplId() {
		return quSumAsrdaplId;
	}

	public void setQuSumAsrdaplId(String quSumAsrdaplId) {
		this.quSumAsrdaplId = quSumAsrdaplId;
	}

	public String getQuiniPremPay() {
		return quiniPremPay;
	}

	public void setQuiniPremPay(String quiniPremPay) {
		this.quiniPremPay = quiniPremPay;
	}

	public String getQuMaturityPeriod() {
		return quMaturityPeriod;
	}

	public void setQuMaturityPeriod(String quMaturityPeriod) {
		this.quMaturityPeriod = quMaturityPeriod;
	}

	public String getAgentTenure() {
		return agentTenure;
	}

	public void setAgentTenure(String agentTenure) {
		this.agentTenure = agentTenure;
	}

	public String getMproBitlyLink() {
		return mproBitlyLink;
	}

	public void setMproBitlyLink(String mproBitlyLink) {
		this.mproBitlyLink = mproBitlyLink;
	}

	public String getEmailDate() {
		return emailDate;
	}

	public void setEmailDate(String emailDate) {
		this.emailDate = emailDate;
	}

	public String getMproProductLink() {
		return mproProductLink;
	}

	public void setMproProductLink(String mproProductLink) {
		this.mproProductLink = mproProductLink;
	}

	public String getModeOfPayment() {
		return modeOfPayment;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	public String getIllustrationLink() {
		return illustrationLink;
	}

	public void setIllustrationLink(String illustrationLink) {
		this.illustrationLink = illustrationLink;
	}

	@Override
	public String toString() {
		return "PIMproSellerTransaction [posvRefNumber=" + posvRefNumber + ", agntVintgDate=" + agntVintgDate
				+ ", agntPersistency=" + agntPersistency + ", psmLogic=" + psmLogic + ", replsmntSale=" + replsmntSale
				+ ", ecsDetails=" + ecsDetails + ", agntMobileNumber=" + agntMobileNumber + ", proposerFirstname="
				+ proposerFirstname + ", proposerLastName=" + proposerLastName + ", proposermidName=" + proposermidName
				+ ", proposerAge=" + proposerAge + ", proposermobNum=" + proposermobNum + ", proposerEmail="
				+ proposerEmail + ", insurAge=" + insurAge + ", insurFirstName=" + insurFirstName + ", insurMidName="
				+ insurMidName + ", insurLastName=" + insurLastName + ", insurMobileNumber=" + insurMobileNumber
				+ ", insurEmail=" + insurEmail + ", typeOfProduct=" + typeOfProduct + ", productName=" + productName
				+ ", insurGroupId=" + insurGroupId + ", premiumPayTerm=" + premiumPayTerm + ", futurePremiumThro="
				+ futurePremiumThro + ", sumAssured=" + sumAssured + ", initialPremiumPaid=" + initialPremiumPaid
				+ ", policyTerm=" + policyTerm + ", dateCreated=" + dateCreated + ", agntId=" + agntId + ", agntGoCode="
				+ agntGoCode + ", agntChanelName=" + agntChanelName + ", smsTrigered=" + smsTrigered + ", smsDate="
				+ smsDate + ", feedBack=" + feedBack + ", feedBackSmsTrigrd=" + feedBackSmsTrigrd
				+ ", dateFeedBackSmsTrigrd=" + dateFeedBackSmsTrigrd + ", agntname=" + agntname
				+ ", verificationSource=" + verificationSource + ", isWopTrue=" + isWopTrue + ", policyNumber="
				+ policyNumber + ", source=" + source + ", referenceKey=" + referenceKey + ", smokerTag=" + smokerTag
				+ ", vestingAge=" + vestingAge + ", fyppReturnPer=" + fyppReturnPer + ", fundType=" + fundType
				+ ", plancode=" + plancode + ", premiumBackOption=" + premiumBackOption + ", guaranteedSumAssured="
				+ guaranteedSumAssured + ", maturityBenefit4pers=" + maturityBenefit4pers + ", maturityBenefit8pers="
				+ maturityBenefit8pers + ", qufName=" + qufName + ", qumName=" + qumName + ", qulName=" + qulName
				+ ", quAge=" + quAge + ", quMobileNo=" + quMobileNo + ", quEmailId=" + quEmailId + ", quInsrAge="
				+ quInsrAge + ", quInsrfName=" + quInsrfName + ", quInsrmName=" + quInsrmName + ", quInsrlName="
				+ quInsrlName + ", quInsrMobileNo=" + quInsrMobileNo + ", quInsrEmailId=" + quInsrEmailId
				+ ", quPersistencyType=" + quPersistencyType + ", quBenefitName=" + quBenefitName + ", custGroupId="
				+ custGroupId + ", quTermPeriod=" + quTermPeriod + ", quPremiumThro=" + quPremiumThro
				+ ", quSumAsrdaplId=" + quSumAsrdaplId + ", quiniPremPay=" + quiniPremPay + ", quMaturityPeriod="
				+ quMaturityPeriod + ", agentTenure=" + agentTenure + ", mproBitlyLink=" + mproBitlyLink
				+ ", emailDate=" + emailDate + ", mproProductLink=" + mproProductLink + ", modeOfPayment="
				+ modeOfPayment + ", illustrationLink=" + illustrationLink + "]";
	}
}