package com.mli.posv.fetchproduct.questions.entity;

import java.io.Serializable;
import java.util.Date;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;



@DynamoDBTable(tableName = "PI_MPRO_BUYER_TRANSACTION")
@JsonIgnoreProperties(ignoreUnknown = true)
public class PiMProBuyerTransaction implements Serializable
{
	private static final long serialVersionUID = -2499939894729077405L;
	
	  @DynamoDBHashKey
	  @JsonProperty("TXN_ID")
	  private String TXNID;	
	  @JsonProperty("QSTN_CAT")
	  private String QSTN_CAT;
	  @JsonProperty("QSTN_ID")
	  private String QSTN_ID;
	  @JsonProperty("QSTN_NAME")
	  private String QSTN_NAME;
	  @JsonProperty("ANSWER")
	  private String ANSWER	;
	  @JsonProperty("CREATED_DT")
	  private Date CREATED_DT;	
	  @JsonProperty("CREATED_BY")
	  private String CREATED_BY;
	  @JsonProperty("OTP_NUMBER")
	  private String OTP_NUMBER	;
	  @JsonProperty("OTP_RCVD_DT")
	  private String OTP_RCVD_DT;
	  @JsonProperty("OTP_FREQ_NO")
	  private String OTP_FREQ_NO;
	  @JsonProperty("QUESTION_TYPE")
	  private String questionType;
	  @JsonProperty("ANSWER_TYPE")
	  private String answerType;
	  @JsonProperty("PARENTID")
	  private String parentId;
	  @JsonProperty("STATUS")
	  private String status;
	public String getTXNID() {
		return TXNID;
	}
	public void setTXNID(String tXNID) {
		TXNID = tXNID;
	}
	public String getQSTN_CAT() {
		return QSTN_CAT;
	}
	public void setQSTN_CAT(String qSTN_CAT) {
		QSTN_CAT = qSTN_CAT;
	}
	public String getQSTN_ID() {
		return QSTN_ID;
	}
	public void setQSTN_ID(String qSTN_ID) {
		QSTN_ID = qSTN_ID;
	}
	public String getQSTN_NAME() {
		return QSTN_NAME;
	}
	public void setQSTN_NAME(String qSTN_NAME) {
		QSTN_NAME = qSTN_NAME;
	}
	public String getANSWER() {
		return ANSWER;
	}
	public void setANSWER(String aNSWER) {
		ANSWER = aNSWER;
	}
	public Date getCREATED_DT() {
		return CREATED_DT;
	}
	public void setCREATED_DT(Date cREATED_DT) {
		CREATED_DT = cREATED_DT;
	}
	public String getCREATED_BY() {
		return CREATED_BY;
	}
	public void setCREATED_BY(String cREATED_BY) {
		CREATED_BY = cREATED_BY;
	}
	public String getOTP_NUMBER() {
		return OTP_NUMBER;
	}
	public void setOTP_NUMBER(String oTP_NUMBER) {
		OTP_NUMBER = oTP_NUMBER;
	}
	public String getOTP_RCVD_DT() {
		return OTP_RCVD_DT;
	}
	public void setOTP_RCVD_DT(String oTP_RCVD_DT) {
		OTP_RCVD_DT = oTP_RCVD_DT;
	}
	public String getOTP_FREQ_NO() {
		return OTP_FREQ_NO;
	}
	public void setOTP_FREQ_NO(String oTP_FREQ_NO) {
		OTP_FREQ_NO = oTP_FREQ_NO;
	}
	public String getQuestionType() {
		return questionType;
	}
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}
	public String getAnswerType() {
		return answerType;
	}
	public void setAnswerType(String answerType) {
		this.answerType = answerType;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "MProBuyerDetailsDTO [TXNID=" + TXNID + ", QSTN_CAT=" + QSTN_CAT + ", QSTN_ID=" + QSTN_ID
				+ ", QSTN_NAME=" + QSTN_NAME + ", ANSWER=" + ANSWER + ", CREATED_DT=" + CREATED_DT + ", CREATED_BY="
				+ CREATED_BY + ", OTP_NUMBER=" + OTP_NUMBER + ", OTP_RCVD_DT=" + OTP_RCVD_DT + ", OTP_FREQ_NO="
				+ OTP_FREQ_NO + ", questionType=" + questionType + ", answerType=" + answerType + ", parentId="
				+ parentId + ", status=" + status + "]";
	}
}
