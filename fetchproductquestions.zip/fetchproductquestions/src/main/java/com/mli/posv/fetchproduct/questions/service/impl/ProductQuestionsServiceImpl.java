package com.mli.posv.fetchproduct.questions.service.impl;

import java.util.List;
import java.util.regex.Pattern;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.mli.posv.fetchproduct.questions.dao.ProductDao;
import com.mli.posv.fetchproduct.questions.dao.impl.ProductDaoImpl;
import com.mli.posv.fetchproduct.questions.entity.PiMproSellerTransaction;
import com.mli.posv.fetchproduct.questions.entity.PiMproQuestionMst;
import com.mli.posv.fetchproduct.questions.request.Request;
import com.mli.posv.fetchproduct.questions.request.Response;
import com.mli.posv.fetchproduct.questions.service.ProductQuestionsService;
import com.mli.posv.fetchproduct.questions.util.AESEncryptor;
import com.mli.posv.fetchproduct.questions.util.StringConstants;

public class ProductQuestionsServiceImpl implements ProductQuestionsService{

	@Override
	public Response getProductQuestions(Request request, Context context) {
		LambdaLogger logger = context.getLogger();
		ProductDao prodDao = new ProductDaoImpl();
		Response response = new Response();
		if (request != null && request.getTxnId() != null && !request.getTxnId().isEmpty()) {
			logger.log("ProductQuestionsServiceImpl : getProductQuestions : START : " + request.getTxnId());
			try {
				String txnIdWithSource = AESEncryptor.decrypt(request.getTxnId());
				String txnIde = txnIdWithSource.split(Pattern.quote(StringConstants.SEPERATOR))[0];
				String appSource=txnIdWithSource.split(Pattern.quote(StringConstants.SEPERATOR))[1];
				
				String AppSourceStatus=prodDao.updateAppSource(txnIde,appSource);
				logger.log("App source status "+AppSourceStatus);
				response.setTxnId(txnIde);
				PiMproSellerTransaction sellerTransaction = prodDao.getPiSellerDetails(txnIde, context);
				if (sellerTransaction != null && sellerTransaction.getCustGroupId() != null
						&& !sellerTransaction.getCustGroupId().isEmpty()) {
					logger.log("sellerTransaction GroupId :: " + sellerTransaction.getCustGroupId());
					response.setSellerInformation(sellerTransaction);
					List<PiMproQuestionMst> slideQuestions = prodDao.getMproSlideQuestionsByCustGroupId(sellerTransaction,context);
					if(slideQuestions!=null && !slideQuestions.isEmpty())
					{
						logger.log("slideQuestionDto " + slideQuestions.size());
						response.setQuestions(slideQuestions);
						
						logger.log("Expiry Link status from seller : "+sellerTransaction.getLinkExpired());
						
						String expiryStatus = prodDao.getExpiryLnikStatus(sellerTransaction.getLinkExpired(), context);
						
						response.setExpiryLink(expiryStatus);
						response.setStatus(StringConstants.SUCCESS);
						response.setDescription(StringConstants.SUCCESS_MSG);
					}else{
						logger.log(StringConstants.BLANK_QUESTIONS);
						response.setStatus(StringConstants.FAILURE);
						response.setDescription(StringConstants.BLANK_QUESTIONS);	
					}
				}
				else{
					logger.log(StringConstants.BLANK_SELLER);
					response.setStatus(StringConstants.FAILURE);
					response.setDescription(StringConstants.BLANK_SELLER);					
				}
			} catch (Exception ex) {
				logger.log(StringConstants.EXCEPTION + StringConstants.COLON + ex);
				response.setStatus(StringConstants.FAILURE);
				response.setDescription(StringConstants.EXCEPTION + StringConstants.COLON + ex.getMessage());
			}
			finally	{
				logger.log("ProductQuestionsServiceImpl : getProductQuestions : END : " + request.getTxnId());
			}

		} else {
			logger.log(StringConstants.INVALIDREQUEST);
			response.setStatus(StringConstants.FAILURE);
			response.setDescription(StringConstants.INVALIDREQUEST);
		}
		return response;
	}

}
