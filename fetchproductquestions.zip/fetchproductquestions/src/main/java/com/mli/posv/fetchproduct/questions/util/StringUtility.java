package com.mli.posv.fetchproduct.questions.util;

public class StringUtility {

	public static String checkStringNullOrBlank(String s) {
		
		if (s != null && !s.equals("") && !s.equalsIgnoreCase("null")) {
			return s.trim().toUpperCase();
		} else {
			return "";
		}
	}
	
	public static String checkStringNullOrBlankWithoutCase(String s) {
		
		if (s != null && !s.equals("") && !s.equalsIgnoreCase("null")) {
			return s.trim();
		} else {
			return "";
		}
	}
}
