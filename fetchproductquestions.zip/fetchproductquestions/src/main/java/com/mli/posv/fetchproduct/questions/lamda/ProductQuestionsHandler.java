package com.mli.posv.fetchproduct.questions.lamda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.mli.posv.fetchproduct.questions.request.Request;
import com.mli.posv.fetchproduct.questions.request.Response;
import com.mli.posv.fetchproduct.questions.service.ProductQuestionsService;
import com.mli.posv.fetchproduct.questions.service.impl.ProductQuestionsServiceImpl;

public class ProductQuestionsHandler implements RequestHandler<Request, Response> {
	@Override
	public Response handleRequest(Request request, Context context) {
		LambdaLogger logger = context.getLogger();
		logger.log("ProductQuestionsHandler : handleRequest : Start");
		ProductQuestionsService productQuestionsService = new ProductQuestionsServiceImpl(); 
		return productQuestionsService.getProductQuestions(request, context);
	}
}
