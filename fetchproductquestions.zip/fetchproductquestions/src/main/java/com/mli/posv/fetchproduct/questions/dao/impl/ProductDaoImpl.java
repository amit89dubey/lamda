package com.mli.posv.fetchproduct.questions.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBQueryExpression;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.Index;
import com.amazonaws.services.dynamodbv2.document.Item;
import com.amazonaws.services.dynamodbv2.document.ItemCollection;
import com.amazonaws.services.dynamodbv2.document.QueryOutcome;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.QuerySpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.AttributeValueUpdate;
import com.amazonaws.services.dynamodbv2.model.ReturnConsumedCapacity;
import com.amazonaws.services.dynamodbv2.model.UpdateItemRequest;
import com.amazonaws.services.dynamodbv2.model.UpdateItemResult;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mli.posv.fetchproduct.questions.dao.ProductDao;
import com.mli.posv.fetchproduct.questions.entity.PiMProBuyerTransaction;
import com.mli.posv.fetchproduct.questions.entity.PiMproSellerTransaction;
import com.mli.posv.fetchproduct.questions.entity.PiMproQuestionMst;
import com.mli.posv.fetchproduct.questions.util.StringConstants;
import com.mli.posv.fetchproduct.questions.util.StringUtility;

public class ProductDaoImpl implements ProductDao {

	public PiMproSellerTransaction getPiSellerDetails(String txnId, Context context) {
		LambdaLogger logger = context.getLogger();
		logger.log("ProductDaoImpl : getPiSellerDetails : Start : " + txnId);
		PiMproSellerTransaction resultSet = new PiMproSellerTransaction();
		try {
			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.defaultClient();
			Map<String, AttributeValue> eav = new HashMap<String, AttributeValue>();
			eav.put(":txnId", new AttributeValue().withS(txnId));
			DynamoDBQueryExpression<PiMproSellerTransaction> queryExpression = new DynamoDBQueryExpression<PiMproSellerTransaction>()
					.withKeyConditionExpression("TXNID = :txnId").withExpressionAttributeValues(eav);
			DynamoDBMapper mapper = new DynamoDBMapper(client);
			logger.log("Mapping DB details in PiMproSellerTransaction : Start");
			List<PiMproSellerTransaction> listResult = mapper.query(PiMproSellerTransaction.class, queryExpression);
			if (listResult != null && !listResult.isEmpty()) {
				resultSet = listResult.get(0);
			} else {
				logger.log(StringConstants.BLANK_DB + StringConstants.COLON + StringConstants.PI_MPRO_SELLER_TRANSACTION
						+ StringConstants.COLON + txnId);
			}
		} catch (Exception e) {
			logger.log(StringConstants.DB_EXCEPTION + StringConstants.COLON + StringConstants.PI_MPRO_SELLER_TRANSACTION
					+ StringConstants.COLON + txnId + StringConstants.COLON + e);
		} finally {
			logger.log("ProductDaoImpl : getPiSellerDetails : End : " + txnId);
		}
		return resultSet;

	}

	public List<PiMproQuestionMst> getMproSlideQuestionsByCustGroupId(PiMproSellerTransaction sellerTransaction,
			Context context) {
		LambdaLogger logger = context.getLogger();
		logger.log("ProductDaoImpl : getMproSlideQuestionsByCustGroupId : Start");
		List<PiMproQuestionMst> slideMproQuestions = new ArrayList();
		List<PiMproQuestionMst> qList = new ArrayList();
		PiMproQuestionMst slideMproQuestion = null;
		ObjectMapper mapper = new ObjectMapper();
		try {
			AmazonDynamoDB client = AmazonDynamoDBClientBuilder.defaultClient();
			DynamoDB dynamoDB = new DynamoDB(client);
			String indexName = "Q_GROUP_ID-index";
			logger.log("GroupId is :::" + sellerTransaction.getCustGroupId());
			Table table = dynamoDB.getTable(StringConstants.PI_MPRO_QUESTION_MST);
			QuerySpec querySpec = new QuerySpec().withScanIndexForward(true)
					.withReturnConsumedCapacity(ReturnConsumedCapacity.TOTAL).withConsistentRead(false);
			logger.log("Using index: " + indexName);
			logger.log("Only a user-specified list of attributes are returned");
			Index index = table.getIndex(indexName);

			querySpec.withKeyConditionExpression("Q_GROUP_ID = :v_source")
					.withValueMap(new ValueMap().withString(":v_source", sellerTransaction.getCustGroupId()));

			ItemCollection<QueryOutcome> items = index.query(querySpec);
			Iterator<Item> iterator = items.iterator();
			logger.log("Iterating data from "+StringConstants.PI_MPRO_QUESTION_MST);
			while (iterator.hasNext()) {
				slideMproQuestion = mapper.readValue(iterator.next().toJSONPretty(), PiMproQuestionMst.class);
				qList.add(slideMproQuestion);

			}
			logger.log("Size of questions List : " + qList.size());

			if (!qList.isEmpty()) {
				for (PiMproQuestionMst questionDto : qList) {
					if (questionDto.getDynamicName() != null && !"".equals(questionDto.getDynamicName())) {
						questionDto.setQuestionName(getMproQuestionName(questionDto.getQuestionName(),
								questionDto.getDynamicName(), sellerTransaction, context));
					}
					slideMproQuestions.add(questionDto);
				}
			}
		} catch (Exception e) {
			logger.log(StringConstants.DB_EXCEPTION + StringConstants.COLON + StringConstants.PI_MPRO_QUESTION_MST
					+ StringConstants.COLON + e);
		} finally {
			logger.log("ProductDaoImpl : getMproSlideQuestionsByCustGroupId : End");
		}
		return slideMproQuestions;
	}

	private String getMproQuestionName(String questionName, String dynamicName, PiMproSellerTransaction resultSet,
			Context context) {
		LambdaLogger logger = context.getLogger();
		logger.log("ProductDaoImpl : getMproQuestionName : Start");
		String question = questionName;
		try {
			if ("MATURITY_YEARS".equalsIgnoreCase(dynamicName)) {
				question = question.replaceAll("<MATURITY_YEARS>", resultSet.getQuMaturityPeriod());
			} else if ("POLICY_COVERAGE_YRS".equalsIgnoreCase(dynamicName)) {
				question = question.replaceAll("<POLICY_COVERAGE_YRS>", resultSet.getQuMaturityPeriod());
			} else if ("PREMIUM_PAY_YRS".equalsIgnoreCase(dynamicName)) {
				question = question.replaceAll("<PREMIUM_PAY_YRS>", resultSet.getPremiumPayTerm());
			} else if ("SUM_ASSURED".equalsIgnoreCase(dynamicName)) {
				question = question.replaceAll("<SUM_ASSURED>", resultSet.getSumAssured());
			} else if ("INITIAL_PREMIUM".equalsIgnoreCase(dynamicName)) {
				question = question.replaceAll("<INITIAL_PREMIUM>", resultSet.getInitialPremiumPaid());
			} else if ("LOCK_IN_PERIOD".equalsIgnoreCase(dynamicName)) {
				if ("TRAD".equalsIgnoreCase(resultSet.getQuPersistencyType())) {
					question = question.replaceAll("<LOCK_IN_PERIOD>", "3");
				} else {
					question = question.replaceAll("<LOCK_IN_PERIOD>", "5");
				}
			} else if ("PRM_PAY_SUM_ASSURED".equalsIgnoreCase(dynamicName)) {
				question = question.replaceAll("<PRM_PAY_SUM_ASSURED>", resultSet.getSumAssured());
			} else if ("EMAIL_ID".equalsIgnoreCase(dynamicName)) {
				question = question.replaceAll("<Email ID>", resultSet.getInsurEmail().toLowerCase());
			}
			// Added by shubham for new slide dynamic values starts
			else if (dynamicName.contains("FUND_TYPE")) {
				question = question.replaceAll("<FUND_TYPE> ", resultSet.getFundType().toUpperCase());
			} else if (dynamicName.contains("GUARANTEED_RETURNS")) {
				question = question.replaceAll("<GUARANTEED_RETURNS>",
						resultSet.getGuaranteedSumAssured().toLowerCase());
			} else if ("VESTING_AGE".equalsIgnoreCase(dynamicName)) {
				question = question.replaceAll("<VESTING_AGE>", resultSet.getVestingAge());
			} else if ("ANNUITY_OPTION".equalsIgnoreCase(dynamicName)) {
				question = question.replaceAll("<ANNUITY_OPTION>", resultSet.getAgentTenure());
			}
			/*
			 * if ("FOUR_PERS,EIGHT_PERS".equalsIgnoreCase(dynamicName)) {
			 * 
			 * if
			 * (StringUtility.checkFieldIsNull(resultSet.getMaturityBenefit4Pers
			 * ())) { resultSet.setMaturityBenefit4Pers(""); }
			 * 
			 * if
			 * (StringUtility.checkFieldIsNull(resultSet.getMaturityBenefit8Pers
			 * ())) { resultSet.setMaturityBenefit8Pers(""); } question =
			 * question.replaceAll("<FOUR_PERS>",
			 * resultSet.getMaturityBenefit4Pers());
			 * 
			 * question = question.replaceAll("<EIGHT_PERS>",
			 * resultSet.getMaturityBenefit8Pers());
			 * 
			 * }
			 */

		} catch (Exception e) {
			logger.log(StringConstants.EXCEPTION + StringConstants.COLON + e);
		}
		finally{
			logger.log("ProductDaoImpl : getMproQuestionName : End");
		}
		return question;
	}

	@Override
	public String getExpiryLnikStatus(String expiryStatus, Context context) {
		LambdaLogger logger = context.getLogger();
		logger.log("ProductDaoImpl : getExpiryLnikStatus : Start");
		String status = StringConstants.STATUS_ZERO;
		try {
				
				if (expiryStatus != null && "Y".equalsIgnoreCase(expiryStatus)) {
					status = StringConstants.STATUS_ONE;
				} else {
					status = StringConstants.STATUS_ZERO;
				}
			
		} catch (Exception e) {
			logger.log(StringConstants.DB_EXCEPTION + StringConstants.COLON + StringConstants.PI_MPRO_BUYER_TRANSACTION
					+ StringConstants.COLON +""+ StringConstants.COLON + e);
		} finally {
			logger.log("ProductDaoImpl : getExpiryLnikStatus : End : ");
		}
		return status;
	}

	@Override
	public String updateAppSource(String txnIde, String appSource) 
	{
		String appSourceStatus="error";
		try {
		Map<String,AttributeValue> attributeValues = new HashMap<>();
		AmazonDynamoDB amazonDynamoDB = AmazonDynamoDBClientBuilder.defaultClient();
	    attributeValues.put("TXNID",new AttributeValue().withS(txnIde));
	    attributeValues.put("VERIFICATION_SOURCE",new AttributeValue().withS(appSource));
	    UpdateItemRequest updateItemRequest = new UpdateItemRequest()
	        .withTableName(StringConstants.PI_MPRO_SELLER_TRANSACTION)
	        .addKeyEntry("TXNID",new AttributeValue().withS(txnIde))
	        .addAttributeUpdatesEntry("VERIFICATION_SOURCE",
	            new AttributeValueUpdate().withValue(new AttributeValue().withS(appSource)));
	    UpdateItemResult updateItemResult = amazonDynamoDB.updateItem(updateItemRequest);
	     
	    if(updateItemResult!=null) {
	    	appSourceStatus="success";
	    }
	    
		}catch(Exception e)
		{
			appSourceStatus="error";
		 System.out.println("Exception in  updateAppSource "+e);	
		}
	    return appSourceStatus;
	}
}