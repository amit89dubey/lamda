package com.mli.posv.savedetails.request;

import java.util.List;

import com.mli.posv.savedetails.entity.PiMproBuyerTransaction;

public class Request {

	String txnId;
	List<PiMproBuyerTransaction> listResponse;
	List<String> idsToDelete;
	
	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public List<String> getIdsToDelete() {
		return idsToDelete;
	}

	public void setIdsToDelete(List<String> idsToDelete) {
		this.idsToDelete = idsToDelete;
	}

	public List<PiMproBuyerTransaction> getListResponse() {
		return listResponse;
	}

	public void setListResponse(List<PiMproBuyerTransaction> listResponse) {
		this.listResponse = listResponse;
	}

	@Override
	public String toString() {
		return "Request [listResponse=" + listResponse + "]";
	}
	
	
}
