package com.mli.posv.savedetails.lamda;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.document.DynamoDB;
import com.amazonaws.services.dynamodbv2.document.PrimaryKey;
import com.amazonaws.services.dynamodbv2.document.Table;
import com.amazonaws.services.dynamodbv2.document.spec.DeleteItemSpec;
import com.amazonaws.services.dynamodbv2.document.utils.ValueMap;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.mli.posv.savedetails.entity.PiMproBuyerTransaction;
import com.mli.posv.savedetails.request.Request;
import com.mli.posv.savedetails.response.Response;
import com.mli.posv.savedetails.util.StringConstants;

public class SaveUserResponse implements RequestHandler<Request, Response> {

	static AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
	static DynamoDB dynamoDB = new DynamoDB(client);
	static DynamoDBMapper mapper = new DynamoDBMapper(client);

	@Override
	public Response handleRequest(Request request, Context context) {
		LambdaLogger logger = context.getLogger();
		Response response = new Response();
		response.setSaveSuccessful(false);
		if (request != null && request.getTxnId() != null && !request.getTxnId().isEmpty()
				&& request.getIdsToDelete() != null && request.getListResponse() != null) {
			logger.log("SaveUserResponse : handleRequest : START : " + request.getTxnId());
			try {
				Table table = dynamoDB.getTable(StringConstants.PI_MPRO_BUYER_TRANSACTION);
				DeleteItemSpec deleteItemSpec;
				if (request.getIdsToDelete() != null && !request.getIdsToDelete().isEmpty()) {
					for (String quesId : request.getIdsToDelete()) {
						logger.log("ID to be deleted : " + quesId);
						deleteItemSpec = new DeleteItemSpec()
								.withPrimaryKey(new PrimaryKey("TXN_ID", request.getTxnId(), "QSTN_ID", quesId))
								.withConditionExpression("QSTN_ID = :val")
								.withValueMap(new ValueMap().with(":val", quesId));
						try {
							table.deleteItem(deleteItemSpec);
						} catch (Exception e) {
							logger.log(StringConstants.DB_EXCEPTION + StringConstants.COLON
									+ StringConstants.PI_MPRO_BUYER_TRANSACTION + StringConstants.COLON
									+ request.getTxnId() + StringConstants.COLON + quesId + StringConstants.COLON + e);
						}
					}
				}

				for (PiMproBuyerTransaction piMpro : request.getListResponse()) {
					if (piMpro.getTxnId() != null && piMpro.getQstnId() != null) {
						mapper.save(piMpro);
					} else {
						logger.log(StringConstants.PI_MPRO_BUYER_TRANSACTION + StringConstants.COLON
								+ StringConstants.INVALIDREQUEST);
						response.setStatus(StringConstants.FAILURE);
						response.setStatus(StringConstants.PI_MPRO_BUYER_TRANSACTION + StringConstants.COLON
								+ StringConstants.INVALIDREQUEST);
					}
				}
				response.setSaveSuccessful(true);
				response.setStatus(StringConstants.SUCCESS);
				response.setStatus(StringConstants.SUCCESS_MSG);
			} catch (Exception ex) {
				logger.log(StringConstants.EXCEPTION + StringConstants.COLON + ex);
				response.setStatus(StringConstants.FAILURE);
				response.setStatus(StringConstants.EXCEPTION + StringConstants.COLON + ex.getMessage());
			} finally {
				logger.log("SaveUserResponse : handleRequest : END : " + request.getTxnId());
			}
		} else {
			logger.log(StringConstants.INVALIDREQUEST);
			response.setStatus(StringConstants.FAILURE);
			response.setStatus(StringConstants.INVALIDREQUEST);
		}
		return response;
	}

}
