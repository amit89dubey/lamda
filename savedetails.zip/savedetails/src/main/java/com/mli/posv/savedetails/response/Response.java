package com.mli.posv.savedetails.response;

public class Response {

	boolean saveSuccessful;
	private String status;
	private String description;
	public boolean isSaveSuccessful() {
		return saveSuccessful;
	}

	public void setSaveSuccessful(boolean saveSuccessful) {
		this.saveSuccessful = saveSuccessful;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "Response [saveSuccessful=" + saveSuccessful + ", status=" + status + ", description=" + description
				+ "]";
	}
	
}
