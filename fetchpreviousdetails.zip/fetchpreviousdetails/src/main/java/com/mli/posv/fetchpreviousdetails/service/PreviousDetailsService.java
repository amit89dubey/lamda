package com.mli.posv.fetchpreviousdetails.service;

import com.amazonaws.services.lambda.runtime.Context;
import com.mli.posv.fetchpreviousdetails.request.Request;
import com.mli.posv.fetchpreviousdetails.response.Response;

public interface PreviousDetailsService {

	Response getPreviousDetails(Request request, Context context);

}
