package com.mli.posv.fetchpreviousdetails.lamda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.mli.posv.fetchpreviousdetails.request.Request;
import com.mli.posv.fetchpreviousdetails.response.Response;
import com.mli.posv.fetchpreviousdetails.service.PreviousDetailsService;
import com.mli.posv.fetchpreviousdetails.service.impl.PreviousDetailsServiceImpl;

public class PreviousDetailsHandler implements RequestHandler<Request, Response>{
    
	@Override
	public Response handleRequest(Request request, Context context) {
		LambdaLogger logger = context.getLogger();
		logger.log("PreviousDetailsHandler : handleRequest : Start");
		PreviousDetailsService previousDetailsService = new PreviousDetailsServiceImpl(); 
		return previousDetailsService.getPreviousDetails(request,context);
	}

}
