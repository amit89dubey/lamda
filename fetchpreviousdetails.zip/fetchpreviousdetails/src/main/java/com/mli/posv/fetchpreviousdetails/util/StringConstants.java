package com.mli.posv.fetchpreviousdetails.util;

public class StringConstants {
	public static final String SUCCESS = "SUCCESS";
	public static final String SUCCESS_MSG = "Request Successfully Processed";
	public static final String FAILURE = "FAILURE";
	public static final String INVALIDREQUEST = "Kindly check your Request details and try again";
	public static final String EXCEPTION = "Something went wrong please connect with customer support";
	
	public static final String DB_EXCEPTION = "We found exception while DB activity";
	public static final String DB_INDEX_TXN_ID = "TXN_ID-index";
	public static final String BLANK_DB = "No data found from database for requested details";
//	public static final String BLANK_SELLER = "Seller information not found aggenst shared transaction please try after sometime";
//	public static final String BLANK_QUESTIONS = "Questions information not found aggenst shared transaction please try after sometime";
	public static final String COLON = " : ";
	//DB details
	public static final String PI_MPRO_BUYER_TRANSACTION = "PI_MPRO_BUYER_TRANSACTION";
	
}
