package com.mli.posv.fetchpreviousdetails.entity;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBAttribute;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBHashKey;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBTable;

@DynamoDBTable(tableName = "PI_MPRO_BUYER_TRANSACTION")
public class PiMproBuyerTransaction {

	@DynamoDBHashKey(attributeName = "TXN_ID")
	private String txnId;
	
	@DynamoDBAttribute(attributeName="QSTN_CAT")
	private String qstnCat;
	
	@DynamoDBHashKey(attributeName = "QSTN_ID")
	private String qstnId;
	
	@DynamoDBAttribute(attributeName="QSTN_NAME")
	private String qstnName;
	
	@DynamoDBAttribute(attributeName = "ANSWER")
	private String answer;
	
	@DynamoDBAttribute(attributeName="CREATED_DT")
	private String createdDt;
	
	@DynamoDBAttribute(attributeName="CREATED_BY")
	private String createdBy;
	
	@DynamoDBAttribute(attributeName = "STATUS")
	private String status;
	
	@DynamoDBAttribute(attributeName="QUESTION_TYPE")
	private String questionType;
	
	@DynamoDBAttribute(attributeName="ANSWER_TYPE")
	private String answerType;
	
	@DynamoDBAttribute(attributeName="PARENTID")
	private String parentid;
	
	@DynamoDBAttribute(attributeName="BACKFLOWSTATUS")
	private String backflowstatus;

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getQstnCat() {
		return qstnCat;
	}

	public void setQstnCat(String qstnCat) {
		this.qstnCat = qstnCat;
	}

	public String getQstnId() {
		return qstnId;
	}

	public void setQstnId(String qstnId) {
		this.qstnId = qstnId;
	}

	public String getQstnName() {
		return qstnName;
	}

	public void setQstnName(String qstnName) {
		this.qstnName = qstnName;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}
	
	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getQuestionType() {
		return questionType;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	public String getAnswerType() {
		return answerType;
	}

	public void setAnswerType(String answerType) {
		this.answerType = answerType;
	}

	public String getParentid() {
		return parentid;
	}

	public void setParentid(String parentid) {
		this.parentid = parentid;
	}

	public String getBackflowstatus() {
		return backflowstatus;
	}

	public void setBackflowstatus(String backflowstatus) {
		this.backflowstatus = backflowstatus;
	}

	@Override
	public String toString() {
		return "PiMproBuyerTransaction [txnId=" + txnId + ", qstnCat=" + qstnCat + ", qstnId=" + qstnId + ", qstnName="
				+ qstnName + ", answer=" + answer + ", createdDt=" + createdDt + ", createdBy=" + createdBy
				+ ", status=" + status + ", questionType=" + questionType + ", answerType=" + answerType + ", parentid="
				+ parentid + ", backflowstatus=" + backflowstatus + "]";
	}
	
	
}
