package com.mli.posv.fetchpreviousdetails.response;

import java.io.Serializable;
import java.util.Map;

import com.mli.posv.fetchpreviousdetails.entity.PiMproBuyerTransaction;

public class Response implements Serializable {
	private static final long serialVersionUID = 1L;
	private String status;
	private String description;
	private Map<String,PiMproBuyerTransaction> response;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Map<String, PiMproBuyerTransaction> getResponse() {
		return response;
	}

	public void setResponse(Map<String, PiMproBuyerTransaction> response) {
		this.response = response;
	}

	@Override
	public String toString() {
		return "Response [status=" + status + ", description=" + description + ", response=" + response + "]";
	}
}
