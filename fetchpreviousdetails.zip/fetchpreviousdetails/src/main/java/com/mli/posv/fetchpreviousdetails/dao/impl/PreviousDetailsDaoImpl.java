package com.mli.posv.fetchpreviousdetails.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBClientBuilder;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBScanExpression;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.ComparisonOperator;
import com.amazonaws.services.dynamodbv2.model.Condition;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.mli.posv.fetchpreviousdetails.dao.PreviousDetailsDao;
import com.mli.posv.fetchpreviousdetails.entity.PiMproBuyerTransaction;
import com.mli.posv.fetchpreviousdetails.request.Request;
import com.mli.posv.fetchpreviousdetails.response.Response;
import com.mli.posv.fetchpreviousdetails.util.StringConstants;

public class PreviousDetailsDaoImpl implements PreviousDetailsDao {

	static AmazonDynamoDB client = AmazonDynamoDBClientBuilder.standard().build();
	static DynamoDBMapper mapper = new DynamoDBMapper(client);

	@Override
	public Response getUserResponse(Request request, Context context) {
		LambdaLogger logger = context.getLogger();
		logger.log("PreviousDetailsDaoImpl : getUserResponse : Start : " + request.getTxnId());
		Response response = new Response();
		Map<String, PiMproBuyerTransaction> responseMap = new HashMap<>();
		try {
			DynamoDBScanExpression scanExpression;
			logger.log("category request : " + request.getCategory());
			if (request.getCategory().equalsIgnoreCase("PRODUCT")) {
				scanExpression = new DynamoDBScanExpression();
				scanExpression.addFilterCondition("TXN_ID",
						new Condition().withComparisonOperator(ComparisonOperator.EQ)
								.withAttributeValueList(new AttributeValue().withS(request.getTxnId())));

				scanExpression.addFilterCondition("QSTN_ID",
						new Condition().withComparisonOperator(ComparisonOperator.EQ)
								.withAttributeValueList(new AttributeValue().withS(request.getQuestionIds().get(0))));
			} else {
				scanExpression = new DynamoDBScanExpression();
				scanExpression.setIndexName(StringConstants.DB_INDEX_TXN_ID);
				logger.log("Index set : " + StringConstants.DB_INDEX_TXN_ID);
				scanExpression.addFilterCondition("TXN_ID",
						new Condition().withComparisonOperator(ComparisonOperator.EQ)
								.withAttributeValueList(new AttributeValue().withS(request.getTxnId())));
				scanExpression.addFilterCondition("QSTN_CAT",
						new Condition().withComparisonOperator(ComparisonOperator.EQ)
								.withAttributeValueList(new AttributeValue().withS(request.getCategory())));
			}
			logger.log("scan expression set completed");
			List<PiMproBuyerTransaction> resultSet = mapper.scan(PiMproBuyerTransaction.class, scanExpression);
			if (resultSet != null && !resultSet.isEmpty()) {
				logger.log("result set not empty with size : " + resultSet.size());
				for (PiMproBuyerTransaction obj : resultSet) {
					responseMap.put(obj.getQstnId(), obj);
				}
			} else {
				logger.log(StringConstants.BLANK_DB + StringConstants.COLON + StringConstants.PI_MPRO_BUYER_TRANSACTION
						+ StringConstants.COLON + request.getTxnId());
			}
		} catch (Exception e) {
			logger.log(StringConstants.DB_EXCEPTION + StringConstants.COLON + StringConstants.PI_MPRO_BUYER_TRANSACTION
					+ StringConstants.COLON + request.getTxnId() + StringConstants.COLON + e);
		} finally {
			logger.log("PreviousDetailsDaoImpl : getUserResponse : End : " + request.getTxnId());
		}
		response.setResponse(responseMap);
		return response;
	}

}
