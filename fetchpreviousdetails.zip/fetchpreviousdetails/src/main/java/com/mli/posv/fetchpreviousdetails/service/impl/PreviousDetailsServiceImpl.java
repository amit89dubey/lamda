package com.mli.posv.fetchpreviousdetails.service.impl;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.mli.posv.fetchpreviousdetails.dao.PreviousDetailsDao;
import com.mli.posv.fetchpreviousdetails.dao.impl.PreviousDetailsDaoImpl;
import com.mli.posv.fetchpreviousdetails.request.Request;
import com.mli.posv.fetchpreviousdetails.response.Response;
import com.mli.posv.fetchpreviousdetails.service.PreviousDetailsService;
import com.mli.posv.fetchpreviousdetails.util.StringConstants;

public class PreviousDetailsServiceImpl implements PreviousDetailsService {

	@Override
	public Response getPreviousDetails(Request request, Context context) {
		LambdaLogger logger = context.getLogger();
		Response response = new Response();
		if (request!=null && request.getTxnId() != null && !request.getTxnId().isEmpty()) {
			logger.log("PreviousDetailsServiceImpl : getResponseBasedOnTxnId : START : " + request.getTxnId());
			try {
				PreviousDetailsDao previousDetailsDao = new PreviousDetailsDaoImpl();
				response = previousDetailsDao.getUserResponse(request, context);
				response.setStatus(StringConstants.SUCCESS);
				response.setStatus(StringConstants.SUCCESS_MSG);
			} catch (Exception ex) {
				logger.log(StringConstants.EXCEPTION + StringConstants.COLON + ex);
				response.setStatus(StringConstants.FAILURE);
				response.setStatus(StringConstants.EXCEPTION + StringConstants.COLON + ex.getMessage());
			} finally {
				logger.log("PreviousDetailsServiceImpl : getResponseBasedOnTxnId : END : " + request.getTxnId());
			}
		} else {
			logger.log(StringConstants.INVALIDREQUEST);
			response.setStatus(StringConstants.FAILURE);
			response.setStatus(StringConstants.INVALIDREQUEST);
		}
		return response;
	}

}
