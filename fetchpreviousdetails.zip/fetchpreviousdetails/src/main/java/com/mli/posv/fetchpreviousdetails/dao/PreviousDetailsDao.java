package com.mli.posv.fetchpreviousdetails.dao;

import com.amazonaws.services.lambda.runtime.Context;
import com.mli.posv.fetchpreviousdetails.request.Request;
import com.mli.posv.fetchpreviousdetails.response.Response;

public interface PreviousDetailsDao {

	Response getUserResponse(Request request, Context context);

}
